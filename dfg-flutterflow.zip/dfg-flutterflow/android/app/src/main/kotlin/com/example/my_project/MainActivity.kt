package com.dfg.dfgmarketplace

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
