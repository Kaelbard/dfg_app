import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 393;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // homeM8C (1:3)
        width: double.infinity,
        height: 1353*fem,
        decoration: BoxDecoration (
          color: Color(0xfff5f5f5),
          borderRadius: BorderRadius.circular(20*fem),
        ),
        child: Stack(
          children: [
            Positioned(
              // barradebuscakJk (1:4)
              left: 16*fem,
              top: 72*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(14*fem, 13*fem, 14*fem, 12.14*fem),
                width: 361*fem,
                height: 50*fem,
                decoration: BoxDecoration (
                  color: Color(0xfffafafa),
                  borderRadius: BorderRadius.circular(20*fem),
                  boxShadow: [
                    BoxShadow(
                      color: Color(0x3f6f7a7a),
                      offset: Offset(1*fem, 1*fem),
                      blurRadius: 0.5*fem,
                    ),
                  ],
                ),
                child: Align(
                  // vectorNL8 (1:6)
                  alignment: Alignment.centerLeft,
                  child: SizedBox(
                    width: 24*fem,
                    height: 24.86*fem,
                    child: Image.asset(
                      'assets/page-1/images/vector-uNx.png',
                      width: 24*fem,
                      height: 24.86*fem,
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // autogrouptzkl5VS (UsyfGXGEMbv4v8Kp45TZkL)
              left: 20*fem,
              top: 351*fem,
              child: Container(
                width: 361*fem,
                height: 16*fem,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // categoriaspopularesbCt (1:7)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 150*fem, 0*fem),
                      child: Text(
                        'Categorias Populares',
                        style: SafeGoogleFont (
                          'Inter',
                          fontSize: 16*ffem,
                          fontWeight: FontWeight.w600,
                          height: 1*ffem/fem,
                          color: Color(0xff131515),
                        ),
                      ),
                    ),
                    Container(
                      // vertodas3qa (1:151)
                      margin: EdgeInsets.fromLTRB(0*fem, 2*fem, 0*fem, 0*fem),
                      child: Text(
                        'ver todas',
                        style: SafeGoogleFont (
                          'Inter',
                          fontSize: 10*ffem,
                          fontWeight: FontWeight.w500,
                          height: 1*ffem/fem,
                          decoration: TextDecoration.underline,
                          color: Color(0xff28af94),
                          decorationColor: Color(0xff28af94),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // frame73YXS (1:12)
              left: 4*fem,
              top: 380*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(16*fem, 2.5*fem, 0*fem, 2.5*fem),
                width: 393*fem,
                height: 110*fem,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // automveisdon (1:13)
                      margin: EdgeInsets.fromLTRB(0*fem, 0.5*fem, 0*fem, 0.5*fem),
                      padding: EdgeInsets.fromLTRB(8*fem, 8*fem, 8*fem, 13*fem),
                      width: 70*fem,
                      height: double.infinity,
                      decoration: BoxDecoration (
                        color: Color(0xfffcfcfc),
                        borderRadius: BorderRadius.circular(10*fem),
                        boxShadow: [
                          BoxShadow(
                            color: Color(0x3f6f7a7a),
                            offset: Offset(1*fem, 1*fem),
                            blurRadius: 0.5*fem,
                          ),
                        ],
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // autogroup6mziRzY (Usyfw5zJk4m8dGzNV16MZi)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 9*fem),
                            padding: EdgeInsets.fromLTRB(7*fem, 12*fem, 8*fem, 17*fem),
                            width: double.infinity,
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(20*fem),
                            ),
                            child: Center(
                              // vectornCp (1:16)
                              child: SizedBox(
                                width: 39*fem,
                                height: 35*fem,
                                child: Image.asset(
                                  'assets/page-1/images/vector-pQp.png',
                                  width: 39*fem,
                                  height: 35*fem,
                                ),
                              ),
                            ),
                          ),
                          Text(
                            // automveisWec (1:17)
                            'Automóveis',
                            style: SafeGoogleFont (
                              'Inter',
                              fontSize: 8*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.2125*ffem/fem,
                              color: Color(0xff0d6352),
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      width: 13*fem,
                    ),
                    Container(
                      // imveisdjE (1:18)
                      margin: EdgeInsets.fromLTRB(0*fem, 0.5*fem, 0*fem, 0.5*fem),
                      padding: EdgeInsets.fromLTRB(8*fem, 8*fem, 8*fem, 13*fem),
                      width: 70*fem,
                      height: double.infinity,
                      decoration: BoxDecoration (
                        color: Color(0xfffcfcfc),
                        borderRadius: BorderRadius.circular(10*fem),
                        boxShadow: [
                          BoxShadow(
                            color: Color(0x3f6f7a7a),
                            offset: Offset(1*fem, 1*fem),
                            blurRadius: 0.5*fem,
                          ),
                        ],
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // autogroupteoiuAx (Usyg6kNsfJ8KTAeDa7teoi)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 9*fem),
                            padding: EdgeInsets.fromLTRB(4*fem, 12*fem, 5.79*fem, 17*fem),
                            width: double.infinity,
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(20*fem),
                            ),
                            child: Center(
                              // vectorCfr (1:22)
                              child: SizedBox(
                                width: 44.21*fem,
                                height: 35*fem,
                                child: Image.asset(
                                  'assets/page-1/images/vector-EcQ.png',
                                  width: 44.21*fem,
                                  height: 35*fem,
                                ),
                              ),
                            ),
                          ),
                          Text(
                            // imveisw7e (1:21)
                            'Imóveis',
                            style: SafeGoogleFont (
                              'Inter',
                              fontSize: 8*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.2125*ffem/fem,
                              color: Color(0xff0d6352),
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      width: 13*fem,
                    ),
                    Container(
                      // jogos4CG (1:23)
                      padding: EdgeInsets.fromLTRB(8*fem, 8.08*fem, 8*fem, 13.22*fem),
                      width: 70*fem,
                      height: double.infinity,
                      decoration: BoxDecoration (
                        color: Color(0xfffcfcfc),
                        borderRadius: BorderRadius.circular(10*fem),
                        boxShadow: [
                          BoxShadow(
                            color: Color(0x3f6f7a7a),
                            offset: Offset(1*fem, 1*fem),
                            blurRadius: 0.5*fem,
                          ),
                        ],
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // autogroupqmdsKtt (UsygEVey3yLodZZ4RiqmdS)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 9.09*fem),
                            padding: EdgeInsets.fromLTRB(3*fem, 12.12*fem, 2.38*fem, 17.16*fem),
                            width: double.infinity,
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(20*fem),
                            ),
                            child: Center(
                              // vectorRwv (1:26)
                              child: SizedBox(
                                width: 48.62*fem,
                                height: 35.34*fem,
                                child: Image.asset(
                                  'assets/page-1/images/vector-Y4Q.png',
                                  width: 48.62*fem,
                                  height: 35.34*fem,
                                ),
                              ),
                            ),
                          ),
                          Text(
                            // jogos97E (1:27)
                            'Jogos',
                            style: SafeGoogleFont (
                              'Inter',
                              fontSize: 8*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.2125*ffem/fem,
                              color: Color(0xff0d6352),
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      width: 13*fem,
                    ),
                    Container(
                      // serviosf5a (1:28)
                      margin: EdgeInsets.fromLTRB(0*fem, 0.5*fem, 0*fem, 0.5*fem),
                      padding: EdgeInsets.fromLTRB(8*fem, 8*fem, 8*fem, 13*fem),
                      width: 70*fem,
                      height: double.infinity,
                      decoration: BoxDecoration (
                        color: Color(0xfffcfcfc),
                        borderRadius: BorderRadius.circular(10*fem),
                        boxShadow: [
                          BoxShadow(
                            color: Color(0x3f6f7a7a),
                            offset: Offset(1*fem, 1*fem),
                            blurRadius: 0.5*fem,
                          ),
                        ],
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // autogroupnttajLL (UsygNEw4SeZHoxTuHKntTA)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 9*fem),
                            padding: EdgeInsets.fromLTRB(10*fem, 12*fem, 9*fem, 17*fem),
                            width: double.infinity,
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(20*fem),
                            ),
                            child: Center(
                              // vector3M2 (1:31)
                              child: SizedBox(
                                width: 35*fem,
                                height: 35*fem,
                                child: Image.asset(
                                  'assets/page-1/images/vector-FG4.png',
                                  width: 35*fem,
                                  height: 35*fem,
                                ),
                              ),
                            ),
                          ),
                          Text(
                            // serviosNeC (1:32)
                            'Serviços',
                            style: SafeGoogleFont (
                              'Inter',
                              fontSize: 8*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.2125*ffem/fem,
                              color: Color(0xff0d6352),
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      width: 13*fem,
                    ),
                    Container(
                      // celularesetablet5oW (1:33)
                      margin: EdgeInsets.fromLTRB(0*fem, 0.5*fem, 0*fem, 0.5*fem),
                      padding: EdgeInsets.fromLTRB(8*fem, 8*fem, 8*fem, 8*fem),
                      width: 70*fem,
                      height: double.infinity,
                      decoration: BoxDecoration (
                        color: Color(0xfffcfcfc),
                        borderRadius: BorderRadius.circular(10*fem),
                        boxShadow: [
                          BoxShadow(
                            color: Color(0x7fdee3e2),
                            offset: Offset(1*fem, 1*fem),
                            blurRadius: 0.5*fem,
                          ),
                        ],
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // autogrouppcpavZE (UsygVVDz8a5gRshnbfPcPA)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                            padding: EdgeInsets.fromLTRB(5*fem, 18*fem, 4.07*fem, 12*fem),
                            width: double.infinity,
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(20*fem),
                            ),
                            child: Center(
                              // vectorqw6 (1:36)
                              child: SizedBox(
                                width: 44.93*fem,
                                height: 34*fem,
                                child: Image.asset(
                                  'assets/page-1/images/vector-jhS.png',
                                  width: 44.93*fem,
                                  height: 34*fem,
                                ),
                              ),
                            ),
                          ),
                          Container(
                            // celularesetabletsm44 (1:37)
                            constraints: BoxConstraints (
                              maxWidth: 38*fem,
                            ),
                            child: Text(
                              'Celulares \ne Tablets',
                              textAlign: TextAlign.center,
                              style: SafeGoogleFont (
                                'Inter',
                                fontSize: 8*ffem,
                                fontWeight: FontWeight.w500,
                                height: 1.2125*ffem/fem,
                                color: Color(0xff0d6352),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // group86TxU (1:38)
              left: 20*fem,
              top: 509*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                width: 902*fem,
                height: 215*fem,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      // promocionais9qJ (1:39)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                      child: Text(
                        'Promocionais',
                        style: SafeGoogleFont (
                          'Inter',
                          fontSize: 16*ffem,
                          fontWeight: FontWeight.w600,
                          height: 1.25*ffem/fem,
                          color: Color(0xff131515),
                        ),
                      ),
                    ),
                    Container(
                      // frame77GQ8 (1:41)
                      width: double.infinity,
                      height: 179*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // vendasoex (1:42)
                            width: 122*fem,
                            height: double.infinity,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Container(
                                  // autogroup6adwMAg (Usygsov8BYxdSX3E1V6aDW)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 10.65*fem),
                                  width: 120*fem,
                                  height: 150*fem,
                                  decoration: BoxDecoration (
                                    color: Color(0xfffafafa),
                                    borderRadius: BorderRadius.circular(10*fem),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Color(0x3f6f7a7a),
                                        offset: Offset(1*fem, 1*fem),
                                        blurRadius: 0.5*fem,
                                      ),
                                    ],
                                  ),
                                  child: Stack(
                                    children: [
                                      Positioned(
                                        // rectangle96q5r (1:45)
                                        left: 51*fem,
                                        top: 8*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 60*fem,
                                            height: 20*fem,
                                            child: Container(
                                              decoration: BoxDecoration (
                                                borderRadius: BorderRadius.circular(10*fem),
                                                color: Color(0xffb04d28),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        // r100000XzG (1:46)
                                        left: 57*fem,
                                        top: 14*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 47*fem,
                                            height: 8*fem,
                                            child: Text(
                                              'R\$ 1.000,00',
                                              style: SafeGoogleFont (
                                                'Inter',
                                                fontSize: 8*ffem,
                                                fontWeight: FontWeight.w600,
                                                height: 1*ffem/fem,
                                                color: Color(0xfffafafa),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // autogroupavhn2RE (UsygxtbzVYVGdhhdKgAvHN)
                                  margin: EdgeInsets.fromLTRB(8*fem, 0*fem, 0*fem, 0*fem),
                                  width: double.infinity,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // vectormNp (1:44)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 23*fem, 0*fem),
                                        width: 20*fem,
                                        height: 18.35*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/vector-GgY.png',
                                          width: 20*fem,
                                          height: 18.35*fem,
                                        ),
                                      ),
                                      Container(
                                        // celta202010Vpc (1:47)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0.35*fem, 0*fem, 0*fem),
                                        child: Text(
                                          'Celta 2.0 2010',
                                          style: SafeGoogleFont (
                                            'Inter',
                                            fontSize: 10*ffem,
                                            fontWeight: FontWeight.w600,
                                            height: 1*ffem/fem,
                                            color: Color(0xff131515),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            width: 8*fem,
                          ),
                          Container(
                            // vendaso4c (1:48)
                            width: 122*fem,
                            height: double.infinity,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Container(
                                  // autogroup7bdjLqE (UsyhCJPKBRYBAAtexH7BDJ)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 10.65*fem),
                                  width: 120*fem,
                                  height: 150*fem,
                                  decoration: BoxDecoration (
                                    color: Color(0xfffafafa),
                                    borderRadius: BorderRadius.circular(10*fem),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Color(0x3f6f7a7a),
                                        offset: Offset(1*fem, 1*fem),
                                        blurRadius: 0.5*fem,
                                      ),
                                    ],
                                  ),
                                  child: Stack(
                                    children: [
                                      Positioned(
                                        // rectangle962TA (1:51)
                                        left: 51*fem,
                                        top: 8*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 60*fem,
                                            height: 20*fem,
                                            child: Container(
                                              decoration: BoxDecoration (
                                                borderRadius: BorderRadius.circular(10*fem),
                                                color: Color(0xffb04d28),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        // r1000007zQ (1:52)
                                        left: 57*fem,
                                        top: 14*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 47*fem,
                                            height: 8*fem,
                                            child: Text(
                                              'R\$ 1.000,00',
                                              style: SafeGoogleFont (
                                                'Inter',
                                                fontSize: 8*ffem,
                                                fontWeight: FontWeight.w600,
                                                height: 1*ffem/fem,
                                                color: Color(0xfffafafa),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // autogroupoy3rcAU (UsyhG8cGEXqaTANfRJoY3r)
                                  margin: EdgeInsets.fromLTRB(8*fem, 0*fem, 0*fem, 0*fem),
                                  width: double.infinity,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // vector88p (1:50)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 23*fem, 0*fem),
                                        width: 20*fem,
                                        height: 18.35*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/vector-WaC.png',
                                          width: 20*fem,
                                          height: 18.35*fem,
                                        ),
                                      ),
                                      Container(
                                        // celta2020103Wg (1:53)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0.35*fem, 0*fem, 0*fem),
                                        child: Text(
                                          'Celta 2.0 2010',
                                          style: SafeGoogleFont (
                                            'Inter',
                                            fontSize: 10*ffem,
                                            fontWeight: FontWeight.w600,
                                            height: 1*ffem/fem,
                                            color: Color(0xff131515),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            width: 8*fem,
                          ),
                          Container(
                            // vendaskR6 (1:54)
                            width: 122*fem,
                            height: double.infinity,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Container(
                                  // autogroup1qrk6Ux (UsyhTnwVxmy9WxiLfV1Qrk)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 10.65*fem),
                                  width: 120*fem,
                                  height: 150*fem,
                                  decoration: BoxDecoration (
                                    color: Color(0xfffafafa),
                                    borderRadius: BorderRadius.circular(10*fem),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Color(0x3f6f7a7a),
                                        offset: Offset(1*fem, 1*fem),
                                        blurRadius: 0.5*fem,
                                      ),
                                    ],
                                  ),
                                  child: Stack(
                                    children: [
                                      Positioned(
                                        // rectangle96mqz (1:57)
                                        left: 51*fem,
                                        top: 8*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 60*fem,
                                            height: 20*fem,
                                            child: Container(
                                              decoration: BoxDecoration (
                                                borderRadius: BorderRadius.circular(10*fem),
                                                color: Color(0xffb04d28),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        // r1000005rg (1:58)
                                        left: 57*fem,
                                        top: 14*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 47*fem,
                                            height: 8*fem,
                                            child: Text(
                                              'R\$ 1.000,00',
                                              style: SafeGoogleFont (
                                                'Inter',
                                                fontSize: 8*ffem,
                                                fontWeight: FontWeight.w600,
                                                height: 1*ffem/fem,
                                                color: Color(0xfffafafa),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // autogroup9nygZWx (UsyhXYLFjResDYFXCy9NYg)
                                  margin: EdgeInsets.fromLTRB(8*fem, 0*fem, 0*fem, 0*fem),
                                  width: double.infinity,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // vectorfpt (1:56)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 23*fem, 0*fem),
                                        width: 20*fem,
                                        height: 18.35*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/vector-2qE.png',
                                          width: 20*fem,
                                          height: 18.35*fem,
                                        ),
                                      ),
                                      Container(
                                        // celta202010nec (1:59)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0.35*fem, 0*fem, 0*fem),
                                        child: Text(
                                          'Celta 2.0 2010',
                                          style: SafeGoogleFont (
                                            'Inter',
                                            fontSize: 10*ffem,
                                            fontWeight: FontWeight.w600,
                                            height: 1*ffem/fem,
                                            color: Color(0xff131515),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            width: 8*fem,
                          ),
                          Container(
                            // vendasUGY (1:60)
                            height: double.infinity,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Container(
                                  // autogroupcrikBwe (UsyhiHXMLd1vkoC7JACrik)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 10.65*fem),
                                  width: 120*fem,
                                  height: 150*fem,
                                  decoration: BoxDecoration (
                                    color: Color(0xfffafafa),
                                    borderRadius: BorderRadius.circular(10*fem),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Color(0x3f6f7a7a),
                                        offset: Offset(1*fem, 1*fem),
                                        blurRadius: 0.5*fem,
                                      ),
                                    ],
                                  ),
                                  child: Stack(
                                    children: [
                                      Positioned(
                                        // rectangle96qFW (1:63)
                                        left: 51*fem,
                                        top: 8*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 60*fem,
                                            height: 20*fem,
                                            child: Container(
                                              decoration: BoxDecoration (
                                                borderRadius: BorderRadius.circular(10*fem),
                                                color: Color(0xffb04d28),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        // r100000X8L (1:64)
                                        left: 57*fem,
                                        top: 14*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 47*fem,
                                            height: 8*fem,
                                            child: Text(
                                              'R\$ 1.000,00',
                                              style: SafeGoogleFont (
                                                'Inter',
                                                fontSize: 8*ffem,
                                                fontWeight: FontWeight.w600,
                                                height: 1*ffem/fem,
                                                color: Color(0xfffafafa),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // autogroup3cc8orY (Usyho2tSWn5qaL5CvB3cC8)
                                  padding: EdgeInsets.fromLTRB(43*fem, 0.35*fem, 0*fem, 0.35*fem),
                                  height: 18.35*fem,
                                  decoration: BoxDecoration (
                                    image: DecorationImage (
                                      fit: BoxFit.cover,
                                      image: AssetImage (
                                        'assets/page-1/images/vector-qdA.png',
                                      ),
                                    ),
                                  ),
                                  child: Text(
                                    'Celta 2.0 2010',
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 10*ffem,
                                      fontWeight: FontWeight.w600,
                                      height: 1*ffem/fem,
                                      color: Color(0xff131515),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            width: 8*fem,
                          ),
                          Container(
                            // vendasf84 (1:66)
                            height: double.infinity,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Container(
                                  // autogroupwfw6R7E (Usyi1n2CvzDHMVhdARWfw6)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 10.65*fem),
                                  width: 120*fem,
                                  height: 150*fem,
                                  decoration: BoxDecoration (
                                    color: Color(0xfffafafa),
                                    borderRadius: BorderRadius.circular(10*fem),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Color(0x3f6f7a7a),
                                        offset: Offset(1*fem, 1*fem),
                                        blurRadius: 0.5*fem,
                                      ),
                                    ],
                                  ),
                                  child: Stack(
                                    children: [
                                      Positioned(
                                        // rectangle966UG (1:69)
                                        left: 51*fem,
                                        top: 8*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 60*fem,
                                            height: 20*fem,
                                            child: Container(
                                              decoration: BoxDecoration (
                                                borderRadius: BorderRadius.circular(10*fem),
                                                color: Color(0xffb04d28),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        // r100000bA8 (1:70)
                                        left: 57*fem,
                                        top: 14*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 47*fem,
                                            height: 8*fem,
                                            child: Text(
                                              'R\$ 1.000,00',
                                              style: SafeGoogleFont (
                                                'Inter',
                                                fontSize: 8*ffem,
                                                fontWeight: FontWeight.w600,
                                                height: 1*ffem/fem,
                                                color: Color(0xfffafafa),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // autogroupo2frgxG (Usyi6SZ6pgfWacdtrto2Fr)
                                  padding: EdgeInsets.fromLTRB(43*fem, 0.35*fem, 0*fem, 0.35*fem),
                                  height: 18.35*fem,
                                  decoration: BoxDecoration (
                                    image: DecorationImage (
                                      fit: BoxFit.cover,
                                      image: AssetImage (
                                        'assets/page-1/images/vector.png',
                                      ),
                                    ),
                                  ),
                                  child: Text(
                                    'Celta 2.0 2010',
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 10*ffem,
                                      fontWeight: FontWeight.w600,
                                      height: 1*ffem/fem,
                                      color: Color(0xff131515),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            width: 8*fem,
                          ),
                          Container(
                            // vendasA6k (1:72)
                            height: double.infinity,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Container(
                                  // autogroupxgvt7ng (UsyiLGVPvrnq59Z47DXGvt)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 10.65*fem),
                                  width: 120*fem,
                                  height: 150*fem,
                                  decoration: BoxDecoration (
                                    color: Color(0xfffafafa),
                                    borderRadius: BorderRadius.circular(10*fem),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Color(0x3f6f7a7a),
                                        offset: Offset(1*fem, 1*fem),
                                        blurRadius: 0.5*fem,
                                      ),
                                    ],
                                  ),
                                  child: Stack(
                                    children: [
                                      Positioned(
                                        // rectangle96zba (1:75)
                                        left: 51*fem,
                                        top: 8*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 60*fem,
                                            height: 20*fem,
                                            child: Container(
                                              decoration: BoxDecoration (
                                                borderRadius: BorderRadius.circular(10*fem),
                                                color: Color(0xffb04d28),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        // r100000hVz (1:76)
                                        left: 57*fem,
                                        top: 14*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 47*fem,
                                            height: 8*fem,
                                            child: Text(
                                              'R\$ 1.000,00',
                                              style: SafeGoogleFont (
                                                'Inter',
                                                fontSize: 8*ffem,
                                                fontWeight: FontWeight.w600,
                                                height: 1*ffem/fem,
                                                color: Color(0xfffafafa),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // autogroupodfeyyJ (UsyiQw2HpZF4JGVKogodFe)
                                  padding: EdgeInsets.fromLTRB(43*fem, 0.35*fem, 0*fem, 0.35*fem),
                                  height: 18.35*fem,
                                  decoration: BoxDecoration (
                                    image: DecorationImage (
                                      fit: BoxFit.cover,
                                      image: AssetImage (
                                        'assets/page-1/images/vector-CMe.png',
                                      ),
                                    ),
                                  ),
                                  child: Text(
                                    'Celta 2.0 2010',
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 10*ffem,
                                      fontWeight: FontWeight.w600,
                                      height: 1*ffem/fem,
                                      color: Color(0xff131515),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            width: 8*fem,
                          ),
                          Container(
                            // vendasEPS (1:78)
                            height: double.infinity,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Container(
                                  // autogroupd5tlPGL (UsyieB9DwX4bdunhbCd5tL)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 10.65*fem),
                                  width: 120*fem,
                                  height: 150*fem,
                                  decoration: BoxDecoration (
                                    color: Color(0xfffafafa),
                                    borderRadius: BorderRadius.circular(10*fem),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Color(0x3f6f7a7a),
                                        offset: Offset(1*fem, 1*fem),
                                        blurRadius: 0.5*fem,
                                      ),
                                    ],
                                  ),
                                  child: Stack(
                                    children: [
                                      Positioned(
                                        // rectangle964dN (1:81)
                                        left: 51*fem,
                                        top: 8*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 60*fem,
                                            height: 20*fem,
                                            child: Container(
                                              decoration: BoxDecoration (
                                                borderRadius: BorderRadius.circular(10*fem),
                                                color: Color(0xffb04d28),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        // r100000AgQ (1:82)
                                        left: 57*fem,
                                        top: 14*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 47*fem,
                                            height: 8*fem,
                                            child: Text(
                                              'R\$ 1.000,00',
                                              style: SafeGoogleFont (
                                                'Inter',
                                                fontSize: 8*ffem,
                                                fontWeight: FontWeight.w600,
                                                height: 1*ffem/fem,
                                                color: Color(0xfffafafa),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // autogroupadexHFE (Usyij6AhgbMseGZT4Jadex)
                                  padding: EdgeInsets.fromLTRB(43*fem, 0.35*fem, 0*fem, 0.35*fem),
                                  height: 18.35*fem,
                                  decoration: BoxDecoration (
                                    image: DecorationImage (
                                      fit: BoxFit.cover,
                                      image: AssetImage (
                                        'assets/page-1/images/vector-xsr.png',
                                      ),
                                    ),
                                  ),
                                  child: Text(
                                    'Celta 2.0 2010',
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 10*ffem,
                                      fontWeight: FontWeight.w600,
                                      height: 1*ffem/fem,
                                      color: Color(0xff131515),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // group88xcG (1:87)
              left: 20*fem,
              top: 740*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                width: 902*fem,
                height: 215*fem,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      // annciosrecentesrhe (1:88)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                      child: Text(
                        'Anúncios recentes',
                        style: SafeGoogleFont (
                          'Inter',
                          fontSize: 16*ffem,
                          fontWeight: FontWeight.w600,
                          height: 1.25*ffem/fem,
                          color: Color(0xff131515),
                        ),
                      ),
                    ),
                    Container(
                      // frame77xkg (1:90)
                      width: double.infinity,
                      height: 179*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // vendasVEp (1:91)
                            width: 122*fem,
                            height: double.infinity,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Container(
                                  // autogroupsa2c2kY (UsyjB5RQDmJrm5VF64sA2c)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 10.65*fem),
                                  width: 120*fem,
                                  height: 150*fem,
                                  decoration: BoxDecoration (
                                    color: Color(0xfffafafa),
                                    borderRadius: BorderRadius.circular(10*fem),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Color(0x3f6f7a7a),
                                        offset: Offset(1*fem, 1*fem),
                                        blurRadius: 0.5*fem,
                                      ),
                                    ],
                                  ),
                                  child: Stack(
                                    children: [
                                      Positioned(
                                        // rectangle96uZS (1:94)
                                        left: 51*fem,
                                        top: 8*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 60*fem,
                                            height: 20*fem,
                                            child: Container(
                                              decoration: BoxDecoration (
                                                borderRadius: BorderRadius.circular(10*fem),
                                                color: Color(0xffb04d28),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        // r1000001sN (1:95)
                                        left: 57*fem,
                                        top: 14*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 47*fem,
                                            height: 8*fem,
                                            child: Text(
                                              'R\$ 1.000,00',
                                              style: SafeGoogleFont (
                                                'Inter',
                                                fontSize: 8*ffem,
                                                fontWeight: FontWeight.w600,
                                                height: 1*ffem/fem,
                                                color: Color(0xfffafafa),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // autogroupgkaqX52 (UsyjF5JjqnqdEtruQBgKAQ)
                                  margin: EdgeInsets.fromLTRB(8*fem, 0*fem, 0*fem, 0*fem),
                                  width: double.infinity,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // vectorFmi (1:93)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 23*fem, 0*fem),
                                        width: 20*fem,
                                        height: 18.35*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/vector-4Yp.png',
                                          width: 20*fem,
                                          height: 18.35*fem,
                                        ),
                                      ),
                                      Container(
                                        // celta202010yhi (1:96)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0.35*fem, 0*fem, 0*fem),
                                        child: Text(
                                          'Celta 2.0 2010',
                                          style: SafeGoogleFont (
                                            'Inter',
                                            fontSize: 10*ffem,
                                            fontWeight: FontWeight.w600,
                                            height: 1*ffem/fem,
                                            color: Color(0xff131515),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            width: 8*fem,
                          ),
                          Container(
                            // vendasHTW (1:97)
                            width: 122*fem,
                            height: double.infinity,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Container(
                                  // autogroupnz1ee3A (UsyjTKTLZFGyTapN7Anz1e)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 10.65*fem),
                                  width: 120*fem,
                                  height: 150*fem,
                                  decoration: BoxDecoration (
                                    color: Color(0xfffafafa),
                                    borderRadius: BorderRadius.circular(10*fem),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Color(0x3f6f7a7a),
                                        offset: Offset(1*fem, 1*fem),
                                        blurRadius: 0.5*fem,
                                      ),
                                    ],
                                  ),
                                  child: Stack(
                                    children: [
                                      Positioned(
                                        // rectangle96LRn (1:100)
                                        left: 51*fem,
                                        top: 8*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 60*fem,
                                            height: 20*fem,
                                            child: Container(
                                              decoration: BoxDecoration (
                                                borderRadius: BorderRadius.circular(10*fem),
                                                color: Color(0xffb04d28),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        // r100000Sji (1:101)
                                        left: 57*fem,
                                        top: 14*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 47*fem,
                                            height: 8*fem,
                                            child: Text(
                                              'R\$ 1.000,00',
                                              style: SafeGoogleFont (
                                                'Inter',
                                                fontSize: 8*ffem,
                                                fontWeight: FontWeight.w600,
                                                height: 1*ffem/fem,
                                                color: Color(0xfffafafa),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // autogroupc99swAg (UsyjXKLgBGojwQC2RHc99S)
                                  margin: EdgeInsets.fromLTRB(8*fem, 0*fem, 0*fem, 0*fem),
                                  width: double.infinity,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // vectors4L (1:99)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 23*fem, 0*fem),
                                        width: 20*fem,
                                        height: 18.35*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/vector-dN8.png',
                                          width: 20*fem,
                                          height: 18.35*fem,
                                        ),
                                      ),
                                      Container(
                                        // celta202010nSC (1:102)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0.35*fem, 0*fem, 0*fem),
                                        child: Text(
                                          'Celta 2.0 2010',
                                          style: SafeGoogleFont (
                                            'Inter',
                                            fontSize: 10*ffem,
                                            fontWeight: FontWeight.w600,
                                            height: 1*ffem/fem,
                                            color: Color(0xff131515),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            width: 8*fem,
                          ),
                          Container(
                            // vendasgnU (1:103)
                            width: 122*fem,
                            height: double.infinity,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Container(
                                  // autogroup8pwupdn (UsyjijBL496GDxhDtq8pWU)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 10.65*fem),
                                  width: 120*fem,
                                  height: 150*fem,
                                  decoration: BoxDecoration (
                                    color: Color(0xfffafafa),
                                    borderRadius: BorderRadius.circular(10*fem),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Color(0x3f6f7a7a),
                                        offset: Offset(1*fem, 1*fem),
                                        blurRadius: 0.5*fem,
                                      ),
                                    ],
                                  ),
                                  child: Stack(
                                    children: [
                                      Positioned(
                                        // rectangle96HXN (1:106)
                                        left: 51*fem,
                                        top: 8*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 60*fem,
                                            height: 20*fem,
                                            child: Container(
                                              decoration: BoxDecoration (
                                                borderRadius: BorderRadius.circular(10*fem),
                                                color: Color(0xffb04d28),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        // r100000Bse (1:107)
                                        left: 57*fem,
                                        top: 14*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 47*fem,
                                            height: 8*fem,
                                            child: Text(
                                              'R\$ 1.000,00',
                                              style: SafeGoogleFont (
                                                'Inter',
                                                fontSize: 8*ffem,
                                                fontWeight: FontWeight.w600,
                                                height: 1*ffem/fem,
                                                color: Color(0xfffafafa),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // autogroupgncqgZW (UsyjnUa5pnmyvYEQSKGnCQ)
                                  margin: EdgeInsets.fromLTRB(8*fem, 0*fem, 0*fem, 0*fem),
                                  width: double.infinity,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // vector2NU (1:105)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 23*fem, 0*fem),
                                        width: 20*fem,
                                        height: 18.35*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/vector-q6p.png',
                                          width: 20*fem,
                                          height: 18.35*fem,
                                        ),
                                      ),
                                      Container(
                                        // celta202010MQk (1:108)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0.35*fem, 0*fem, 0*fem),
                                        child: Text(
                                          'Celta 2.0 2010',
                                          style: SafeGoogleFont (
                                            'Inter',
                                            fontSize: 10*ffem,
                                            fontWeight: FontWeight.w600,
                                            height: 1*ffem/fem,
                                            color: Color(0xff131515),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            width: 8*fem,
                          ),
                          Container(
                            // vendasEUY (1:109)
                            height: double.infinity,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Container(
                                  // autogroupifbnbK6 (UsyjzUE6gsNHMzMPNfiFbn)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 10.65*fem),
                                  width: 120*fem,
                                  height: 150*fem,
                                  decoration: BoxDecoration (
                                    color: Color(0xfffafafa),
                                    borderRadius: BorderRadius.circular(10*fem),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Color(0x3f6f7a7a),
                                        offset: Offset(1*fem, 1*fem),
                                        blurRadius: 0.5*fem,
                                      ),
                                    ],
                                  ),
                                  child: Stack(
                                    children: [
                                      Positioned(
                                        // rectangle96Utg (1:112)
                                        left: 51*fem,
                                        top: 8*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 60*fem,
                                            height: 20*fem,
                                            child: Container(
                                              decoration: BoxDecoration (
                                                borderRadius: BorderRadius.circular(10*fem),
                                                color: Color(0xffb04d28),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        // r100000z6L (1:113)
                                        left: 57*fem,
                                        top: 14*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 47*fem,
                                            height: 8*fem,
                                            child: Text(
                                              'R\$ 1.000,00',
                                              style: SafeGoogleFont (
                                                'Inter',
                                                fontSize: 8*ffem,
                                                fontWeight: FontWeight.w600,
                                                height: 1*ffem/fem,
                                                color: Color(0xfffafafa),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // autogroupsodjhWY (Usyk4y6c1eb9QHQ1E3sodJ)
                                  padding: EdgeInsets.fromLTRB(43*fem, 0.35*fem, 0*fem, 0.35*fem),
                                  height: 18.35*fem,
                                  decoration: BoxDecoration (
                                    image: DecorationImage (
                                      fit: BoxFit.cover,
                                      image: AssetImage (
                                        'assets/page-1/images/vector-SUg.png',
                                      ),
                                    ),
                                  ),
                                  child: Text(
                                    'Celta 2.0 2010',
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 10*ffem,
                                      fontWeight: FontWeight.w600,
                                      height: 1*ffem/fem,
                                      color: Color(0xff131515),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            width: 8*fem,
                          ),
                          Container(
                            // vendasyU4 (1:115)
                            height: double.infinity,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Container(
                                  // autogroupe552w9z (UsykHYZyrwVDzd8mdDE552)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 10.65*fem),
                                  width: 120*fem,
                                  height: 150*fem,
                                  decoration: BoxDecoration (
                                    color: Color(0xfffafafa),
                                    borderRadius: BorderRadius.circular(10*fem),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Color(0x3f6f7a7a),
                                        offset: Offset(1*fem, 1*fem),
                                        blurRadius: 0.5*fem,
                                      ),
                                    ],
                                  ),
                                  child: Stack(
                                    children: [
                                      Positioned(
                                        // rectangle961fe (1:118)
                                        left: 51*fem,
                                        top: 8*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 60*fem,
                                            height: 20*fem,
                                            child: Container(
                                              decoration: BoxDecoration (
                                                borderRadius: BorderRadius.circular(10*fem),
                                                color: Color(0xffb04d28),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        // r100000uFE (1:119)
                                        left: 57*fem,
                                        top: 14*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 47*fem,
                                            height: 8*fem,
                                            child: Text(
                                              'R\$ 1.000,00',
                                              style: SafeGoogleFont (
                                                'Inter',
                                                fontSize: 8*ffem,
                                                fontWeight: FontWeight.w600,
                                                height: 1*ffem/fem,
                                                color: Color(0xfffafafa),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // autogrouppd6yAwr (UsykN3SVBii62vBPUbPd6Y)
                                  padding: EdgeInsets.fromLTRB(43*fem, 0.35*fem, 0*fem, 0.35*fem),
                                  height: 18.35*fem,
                                  decoration: BoxDecoration (
                                    image: DecorationImage (
                                      fit: BoxFit.cover,
                                      image: AssetImage (
                                        'assets/page-1/images/vector-hYC.png',
                                      ),
                                    ),
                                  ),
                                  child: Text(
                                    'Celta 2.0 2010',
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 10*ffem,
                                      fontWeight: FontWeight.w600,
                                      height: 1*ffem/fem,
                                      color: Color(0xff131515),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            width: 8*fem,
                          ),
                          Container(
                            // vendas2DN (1:121)
                            height: double.infinity,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Container(
                                  // autogroupbvpeBMA (UsykaY5fkYzV2qyKxDBVPe)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 10.65*fem),
                                  width: 120*fem,
                                  height: 150*fem,
                                  decoration: BoxDecoration (
                                    color: Color(0xfffafafa),
                                    borderRadius: BorderRadius.circular(10*fem),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Color(0x3f6f7a7a),
                                        offset: Offset(1*fem, 1*fem),
                                        blurRadius: 0.5*fem,
                                      ),
                                    ],
                                  ),
                                  child: Stack(
                                    children: [
                                      Positioned(
                                        // rectangle96riC (1:124)
                                        left: 51*fem,
                                        top: 8*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 60*fem,
                                            height: 20*fem,
                                            child: Container(
                                              decoration: BoxDecoration (
                                                borderRadius: BorderRadius.circular(10*fem),
                                                color: Color(0xffb04d28),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        // r100000Mur (1:125)
                                        left: 57*fem,
                                        top: 14*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 47*fem,
                                            height: 8*fem,
                                            child: Text(
                                              'R\$ 1.000,00',
                                              style: SafeGoogleFont (
                                                'Inter',
                                                fontSize: 8*ffem,
                                                fontWeight: FontWeight.w600,
                                                height: 1*ffem/fem,
                                                color: Color(0xfffafafa),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // autogroupfqyjr5v (UsykenTbDxNJHuBU2xfqyJ)
                                  padding: EdgeInsets.fromLTRB(43*fem, 0.35*fem, 0*fem, 0.35*fem),
                                  height: 18.35*fem,
                                  decoration: BoxDecoration (
                                    image: DecorationImage (
                                      fit: BoxFit.cover,
                                      image: AssetImage (
                                        'assets/page-1/images/vector-yT6.png',
                                      ),
                                    ),
                                  ),
                                  child: Text(
                                    'Celta 2.0 2010',
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 10*ffem,
                                      fontWeight: FontWeight.w600,
                                      height: 1*ffem/fem,
                                      color: Color(0xff131515),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            width: 8*fem,
                          ),
                          Container(
                            // vendasWwA (1:127)
                            height: double.infinity,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Container(
                                  // autogroupzx5sUsz (UsykrcTDX7jEYXQo8DzX5S)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 10.65*fem),
                                  width: 120*fem,
                                  height: 150*fem,
                                  decoration: BoxDecoration (
                                    color: Color(0xfffafafa),
                                    borderRadius: BorderRadius.circular(10*fem),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Color(0x3f6f7a7a),
                                        offset: Offset(1*fem, 1*fem),
                                        blurRadius: 0.5*fem,
                                      ),
                                    ],
                                  ),
                                  child: Stack(
                                    children: [
                                      Positioned(
                                        // rectangle96ms6 (1:130)
                                        left: 51*fem,
                                        top: 8*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 60*fem,
                                            height: 20*fem,
                                            child: Container(
                                              decoration: BoxDecoration (
                                                borderRadius: BorderRadius.circular(10*fem),
                                                color: Color(0xffb04d28),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        // r100000UWc (1:131)
                                        left: 57*fem,
                                        top: 14*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 47*fem,
                                            height: 8*fem,
                                            child: Text(
                                              'R\$ 1.000,00',
                                              style: SafeGoogleFont (
                                                'Inter',
                                                fontSize: 8*ffem,
                                                fontWeight: FontWeight.w600,
                                                height: 1*ffem/fem,
                                                color: Color(0xfffafafa),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // autogroupqgypkyv (UsykwMpJhGo9N4HtkEqGYp)
                                  padding: EdgeInsets.fromLTRB(43*fem, 0.35*fem, 0*fem, 0.35*fem),
                                  height: 18.35*fem,
                                  decoration: BoxDecoration (
                                    image: DecorationImage (
                                      fit: BoxFit.cover,
                                      image: AssetImage (
                                        'assets/page-1/images/vector-UbJ.png',
                                      ),
                                    ),
                                  ),
                                  child: Text(
                                    'Celta 2.0 2010',
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 10*ffem,
                                      fontWeight: FontWeight.w600,
                                      height: 1*ffem/fem,
                                      color: Color(0xff131515),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // autogroupc3egSbr (UsyeVxi9Y6mrVFbm9yc3EG)
              left: 16*fem,
              top: 16*fem,
              child: Container(
                width: 361.43*fem,
                height: 46.12*fem,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // logotemporriaMTv (1:136)
                      width: 36*fem,
                      height: 46.12*fem,
                      child: Image.asset(
                        'assets/page-1/images/logo-temporria.png',
                        width: 36*fem,
                        height: 46.12*fem,
                      ),
                    ),
                    Container(
                      // autogroupuz32592 (Usyeux2BGFxTN9qj2gUz32)
                      padding: EdgeInsets.fromLTRB(190*fem, 8*fem, 0*fem, 6.12*fem),
                      height: double.infinity,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // autogroupyu1aPvQ (UsyejHfGwXD5RJqxs2yu1a)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 9*fem, 0*fem),
                            width: 99*fem,
                            height: double.infinity,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Container(
                                  // johndoe87J (1:155)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 5*fem),
                                  width: double.infinity,
                                  child: Text(
                                    'John Doe',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 12*ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 1*ffem/fem,
                                      color: Color(0xff131515),
                                    ),
                                  ),
                                ),
                                Container(
                                  // saldor23400FBv (1:154)
                                  width: double.infinity,
                                  child: RichText(
                                    textAlign: TextAlign.center,
                                    text: TextSpan(
                                      style: SafeGoogleFont (
                                        'Inter',
                                        fontSize: 12*ffem,
                                        fontWeight: FontWeight.w600,
                                        height: 1.2102272511*ffem/fem,
                                        color: Color(0xff131515),
                                      ),
                                      children: [
                                        TextSpan(
                                          text: 'Saldo: ',
                                          style: SafeGoogleFont (
                                            'Inter',
                                            fontSize: 12*ffem,
                                            fontWeight: FontWeight.w500,
                                            height: 1.2125*ffem/fem,
                                            color: Color(0xff131515),
                                          ),
                                        ),
                                        TextSpan(
                                          text: 'R\$ 234,00',
                                          style: SafeGoogleFont (
                                            'Inter',
                                            fontSize: 12*ffem,
                                            fontWeight: FontWeight.w500,
                                            height: 1.2125*ffem/fem,
                                            color: Color(0xff28af94),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // autogroupxsgq6EU (Usyeq2zhXBfBMo4yZaXSGQ)
                            width: 27.43*fem,
                            height: 32*fem,
                            child: Image.asset(
                              'assets/page-1/images/auto-group-xsgq.png',
                              width: 27.43*fem,
                              height: 32*fem,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // group84DZz (1:141)
              left: 20*fem,
              top: 971*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                width: 377*fem,
                height: 347*fem,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      // oportunidadesime (1:142)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 7*fem),
                      width: double.infinity,
                      child: Text(
                        'Oportunidades',
                        textAlign: TextAlign.center,
                        style: SafeGoogleFont (
                          'Inter',
                          fontSize: 20*ffem,
                          fontWeight: FontWeight.w600,
                          height: 1.2125*ffem/fem,
                          color: Color(0xff131515),
                        ),
                      ),
                    ),
                    Container(
                      // frame79ddi (1:146)
                      width: double.infinity,
                      height: 307*fem,
                      child: Container(
                        // frame78zDN (1:147)
                        width: 948*fem,
                        height: 300*fem,
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              // image2XUC (1:148)
                              width: 300*fem,
                              height: 300*fem,
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(20*fem),
                                child: Image.asset(
                                  'assets/page-1/images/image-2.png',
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                            SizedBox(
                              width: 24*fem,
                            ),
                            Container(
                              // image3pTJ (1:149)
                              width: 300*fem,
                              height: 300*fem,
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(20*fem),
                                child: Image.asset(
                                  'assets/page-1/images/image-3.png',
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                            SizedBox(
                              width: 24*fem,
                            ),
                            Container(
                              // image4w28 (1:150)
                              width: 300*fem,
                              height: 300*fem,
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(20*fem),
                                child: Image.asset(
                                  'assets/page-1/images/image-4.png',
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // rectangle119UGx (1:156)
              left: 16*fem,
              top: 146*fem,
              child: Align(
                child: SizedBox(
                  width: 361*fem,
                  height: 165*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(10*fem),
                      color: Color(0xff7265c3),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x3f6f7a7a),
                          offset: Offset(1*fem, 1*fem),
                          blurRadius: 0.5*fem,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // menu9P6 (1:157)
              left: 11*fem,
              top: 760*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(27*fem, 8*fem, 36*fem, 7*fem),
                width: 379*fem,
                height: 75*fem,
                decoration: BoxDecoration (
                  color: Color(0xfffafafa),
                  borderRadius: BorderRadius.circular(30*fem),
                  boxShadow: [
                    BoxShadow(
                      color: Color(0x3f6f7a7a),
                      offset: Offset(1*fem, 1*fem),
                      blurRadius: 0.5*fem,
                    ),
                  ],
                ),
                child: Container(
                  // frame752St (1:159)
                  width: double.infinity,
                  height: double.infinity,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        // autogroupt4szyd2 (Usymb6ESF9VP95WBwit4sz)
                        padding: EdgeInsets.fromLTRB(0*fem, 14*fem, 32*fem, 14*fem),
                        height: double.infinity,
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              // vector7UL (1:160)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 32*fem, 0*fem),
                              width: 32*fem,
                              height: 32*fem,
                              child: Image.asset(
                                'assets/page-1/images/vector-JZn.png',
                                width: 32*fem,
                                height: 32*fem,
                              ),
                            ),
                            Container(
                              // group78qQL (1:161)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0*fem),
                              width: 32*fem,
                              height: 32*fem,
                              child: Image.asset(
                                'assets/page-1/images/group-78.png',
                                width: 32*fem,
                                height: 32*fem,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        // group79YpY (1:167)
                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 32*fem, 0*fem),
                        padding: EdgeInsets.fromLTRB(14*fem, 14*fem, 14*fem, 14*fem),
                        height: double.infinity,
                        decoration: BoxDecoration (
                          color: Color(0xff28af94),
                          borderRadius: BorderRadius.circular(30*fem),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x7fdee3e2),
                              offset: Offset(1*fem, 1*fem),
                              blurRadius: 0.5*fem,
                            ),
                          ],
                        ),
                        child: Center(
                          // vectorqoe (1:169)
                          child: SizedBox(
                            width: 32*fem,
                            height: 32*fem,
                            child: Image.asset(
                              'assets/page-1/images/vector-EP2.png',
                              width: 32*fem,
                              height: 32*fem,
                            ),
                          ),
                        ),
                      ),
                      Container(
                        // vectoraWL (1:170)
                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 32*fem, 0*fem),
                        width: 32*fem,
                        height: 32*fem,
                        child: Image.asset(
                          'assets/page-1/images/vector-aqe.png',
                          width: 32*fem,
                          height: 32*fem,
                        ),
                      ),
                      Container(
                        // vectoriMe (1:171)
                        width: 32*fem,
                        height: 32*fem,
                        child: Image.asset(
                          'assets/page-1/images/vector-YVe.png',
                          width: 32*fem,
                          height: 32*fem,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}