import 'package:flutter/material.dart';
import 'package:flutterapp/dfgapp/generatediphone14pro1widget/GeneratedIPhone14Pro1Widget.dart';
import 'package:flutterapp/dfgapp/generatedgroup85widget/GeneratedGroup85Widget.dart';
import 'package:flutterapp/dfgapp/generatedrectangle101widget/GeneratedRectangle101Widget.dart';
import 'package:flutterapp/dfgapp/generatedrectangle104widget/GeneratedRectangle104Widget.dart';
import 'package:flutterapp/dfgapp/generatedrectangle107widget/GeneratedRectangle107Widget.dart';
import 'package:flutterapp/dfgapp/generatedrectangle114widget/GeneratedRectangle114Widget.dart';
import 'package:flutterapp/dfgapp/generatedrectangle102widget/GeneratedRectangle102Widget.dart';
import 'package:flutterapp/dfgapp/generatedrectangle105widget/GeneratedRectangle105Widget.dart';
import 'package:flutterapp/dfgapp/generatedrectangle108widget/GeneratedRectangle108Widget.dart';
import 'package:flutterapp/dfgapp/generatedrectangle115widget/GeneratedRectangle115Widget.dart';
import 'package:flutterapp/dfgapp/generatedrectangle110widget/GeneratedRectangle110Widget.dart';
import 'package:flutterapp/dfgapp/generatedrectangle116widget/GeneratedRectangle116Widget.dart';
import 'package:flutterapp/dfgapp/generatedrectangle112widget/GeneratedRectangle112Widget.dart';
import 'package:flutterapp/dfgapp/generatedrectangle103widget/GeneratedRectangle103Widget.dart';
import 'package:flutterapp/dfgapp/generatedrectangle106widget/GeneratedRectangle106Widget.dart';
import 'package:flutterapp/dfgapp/generatedrectangle109widget/GeneratedRectangle109Widget.dart';
import 'package:flutterapp/dfgapp/generatedrectangle117widget/GeneratedRectangle117Widget.dart';
import 'package:flutterapp/dfgapp/generatedrectangle111widget/GeneratedRectangle111Widget.dart';
import 'package:flutterapp/dfgapp/generatedrectangle118widget/GeneratedRectangle118Widget.dart';
import 'package:flutterapp/dfgapp/generatedrectangle113widget/GeneratedRectangle113Widget.dart';
import 'package:flutterapp/dfgapp/generatedmdiuseroutlinewidget/GeneratedMdiuseroutlineWidget.dart';
import 'package:flutterapp/dfgapp/generatediphone141widget/GeneratedIPhone141Widget.dart';

void main() {
  runApp(DFGApp());
}

class DFGApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      initialRoute: '/GeneratedIPhone14Pro1Widget',
      routes: {
        '/GeneratedIPhone14Pro1Widget': (context) =>
            GeneratedIPhone14Pro1Widget(),
        '/GeneratedGroup85Widget': (context) => GeneratedGroup85Widget(),
        '/GeneratedRectangle101Widget': (context) =>
            GeneratedRectangle101Widget(),
        '/GeneratedRectangle104Widget': (context) =>
            GeneratedRectangle104Widget(),
        '/GeneratedRectangle107Widget': (context) =>
            GeneratedRectangle107Widget(),
        '/GeneratedRectangle114Widget': (context) =>
            GeneratedRectangle114Widget(),
        '/GeneratedRectangle102Widget': (context) =>
            GeneratedRectangle102Widget(),
        '/GeneratedRectangle105Widget': (context) =>
            GeneratedRectangle105Widget(),
        '/GeneratedRectangle108Widget': (context) =>
            GeneratedRectangle108Widget(),
        '/GeneratedRectangle115Widget': (context) =>
            GeneratedRectangle115Widget(),
        '/GeneratedRectangle110Widget': (context) =>
            GeneratedRectangle110Widget(),
        '/GeneratedRectangle116Widget': (context) =>
            GeneratedRectangle116Widget(),
        '/GeneratedRectangle112Widget': (context) =>
            GeneratedRectangle112Widget(),
        '/GeneratedRectangle103Widget': (context) =>
            GeneratedRectangle103Widget(),
        '/GeneratedRectangle106Widget': (context) =>
            GeneratedRectangle106Widget(),
        '/GeneratedRectangle109Widget': (context) =>
            GeneratedRectangle109Widget(),
        '/GeneratedRectangle117Widget': (context) =>
            GeneratedRectangle117Widget(),
        '/GeneratedRectangle111Widget': (context) =>
            GeneratedRectangle111Widget(),
        '/GeneratedRectangle118Widget': (context) =>
            GeneratedRectangle118Widget(),
        '/GeneratedRectangle113Widget': (context) =>
            GeneratedRectangle113Widget(),
        '/GeneratedMdiuseroutlineWidget': (context) =>
            GeneratedMdiuseroutlineWidget(),
        '/GeneratedIPhone141Widget': (context) => GeneratedIPhone141Widget(),
      },
    );
  }
}
